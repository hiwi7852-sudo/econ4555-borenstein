# Question 11: Python code submission

This package contains the 10 reusable Python scripts created or used for the ECON 4555 Borenstein analysis, plus requirements.txt. It excludes raw datasets, generated tables, caches and temporary helpers.

Run from the repository root with the Python dependencies in requirements.txt installed. The raw archives must exist under data/raw/2025Q2, or be acquired with the download scripts. The source Borenstein PDF is not included.

## Script order and purpose

1. scripts/fetch_bts.py — guarded official DB1B ZIP downloads; invoked separately for Market, Ticket and Coupon.
2. scripts/fetch_t100_months.py — guarded official April–June 2025 T-100 Segment extracts.
3. scripts/prepare_q4.py --ingest — stream CSVs from ZIPs into the local DuckDB database and validate periods/keys.
4. scripts/build_q4.py — create fare percentiles, controls, shares and the one-carrier-per-route baseline.
5. scripts/summarize_part3_q4.py — Part III Q4 summary statistics and LaTeX source.
6. scripts/table1_part3_q5.py — Part III Q5 modern Table 1 calculations and validation.
7. scripts/render_table1_part3_q5.py — format modern Table 1 as LaTeX.
8. scripts/ols_part3_q6.py — Part III Q6 OLS, carrier fixed effects, HC1 inference and numerical verification.
9. scripts/render_table2_part3_q6.py — modern Table 2 LaTeX and coefficient interpretations.
10. scripts/nonstop_connecting_part3_q9.py — Part III Q9 weighted fare and matched-market comparisons using coupon-path proxies.

Compile the generated .tex files with pdflatex separately. Question 7 was a written comparison using the original paper and saved Q6 coefficients; it did not require a separate script.

The exploratory helper /workspace/work/get_t100.py was superseded by scripts/fetch_t100_months.py; it is not needed to reproduce the analysis and is excluded.

Submission bundle: all 10 scripts and requirements.txt are included. Source files belong in scripts/ at the repository root; this ZIP is a convenience copy of the same code.
